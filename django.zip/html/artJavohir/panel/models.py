from django.db import models

# Create your models here.

class Art(models.Model):
    name = models.TextField()
    birthday = models.TextField()
    deathday = models.TextField()


from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import *

# Create your views here.


def main(request):
    data = {
        'artist' : Art.objects.all()
    }
    return render(request,'panel.html', data)

def add(request):
    return render(request,'artadd.html')

def save(request):
    if request.method == 'GET':
        return HttpResponse('Get Method Nerealizovan')

    art = Art()
    art.name = request.POST['name']
    art.birthday = request.POST['birthday']
    art.deathday = request.POST['deathday']

    art.save()

    return HttpResponseRedirect('/panel/')
    
def delete(request):
    artId = request.GET['id']

    art = Art.objects.get(id=artId)
    art.delete()
    return HttpResponseRedirect('/panel/')

def editvibor(request):
    artId = request.GET['id']

    art = Art.objects.get(id=artId)
    data = {
        'art' : Art.objects.get(id =artId)
    }
    

    return render(request, 'editvibor.html', data )

def edit(request):
    artId = request.GET['id']
    art = Art.objects.get(id=artId)

    if request.POST['name'] > "":
        art.name = request.POST['name']
    if request.POST['birthday'] > "":
        art.birthday = request.POST['birthday'] 
    if request.POST['deathday'] > "" : 
        art.deathday = request.POST['deathday']


    art.save()
    return HttpResponseRedirect('/panel/')











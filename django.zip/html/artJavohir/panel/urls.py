from django.contrib import admin
from django.urls import path
from .views import *


urlpatterns = [
    path('', main),
    path('artadd', add),
    path('save', save),
    path('delete', delete),
    path('editvbr', editvibor),
    path('edit', edit)
]